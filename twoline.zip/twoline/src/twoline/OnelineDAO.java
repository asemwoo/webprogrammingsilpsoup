package twoline;

import java.sql.Connection;  
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;


public class OnelineDAO {	//Date Access Object 	db�� �����ϴ� ��
	
	//private Connection con;
	private	String url ; 
	private String user ; 
	private String passwd; 
	
			
			 
	public OnelineDAO() //������
	{
		this.url ="jdbc:mysql://localhost/world?characterEncoding=UTF-8&serverTimezone=UTC";
		this.user= "root";
		this.passwd= "1234";
		 
	}
	 
		private Connection connect() {
				Connection con = null;
				try {
					Class.forName("com.mysql.cj.jdbc.Driver");
					con = DriverManager.getConnection(url, user, passwd);
					
				} catch (ClassNotFoundException e) {
					e.printStackTrace();
				} catch (SQLException e) {
						e.printStackTrace();
				} 
								//02:02:00 ���� �ٽ� ���. �� �� ��ħ
				return con;
	}
	


	public ArrayList<OneineDTO> getlist()
	{
		Connection con = null;
		String sql = " select * from oneline order by no desc ";
		ResultSet rs = null;
		PreparedStatement pstmt = null;
		ArrayList<OneineDTO> dtos = new ArrayList<OneineDTO>();

	  
		try {
			
			con = connect();
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				int no = rs.getInt("no");
				String memo = rs.getString("memo");
				String wdate = rs.getString("wdate");
				
				OneineDTO dto = new OneineDTO(no,memo,wdate);
				dtos.add(dto);
				
			}
		
		}catch(SQLException e) {
				e.printStackTrace();
			} finally {
				try {
				
					if(rs != null) rs.close();
					if(pstmt != null)pstmt.close();
					if(con != null)con.close();
			}catch (Exception e) {
				e.printStackTrace();
				
			}
		}
			return dtos;	
	}
	
	
	public void insert(OneineDTO dto)
{
		Connection con = null;
		String sql = "insert into oneline(memo) values(?)";
		PreparedStatement pstmt = null;
		try {
				con = connect();
				pstmt = con.prepareStatement(sql);
				pstmt.setString(1, dto.getMemo());
				pstmt.executeUpdate();
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
				try {
					if(pstmt != null) pstmt.close();
					if(con != null) con.close();
				} catch (Exception e) {
					// TODO: handle exception
					e.printStackTrace();
				}
		}			
	}
}
		
			
		
